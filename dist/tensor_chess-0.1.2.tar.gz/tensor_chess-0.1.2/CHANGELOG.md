# Changelog

All notable changes to this project will be documented in this file.

## [0.1.2] - 2025-10-04
### Added
- Added support for building the C extension on Windows and Linux via adaptive compiler flags.

## [0.1.1] - 2024-10-02
### Added
- Initial release of the `tensor-chess` library.
